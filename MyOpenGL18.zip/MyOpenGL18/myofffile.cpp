#include "myofffile.h"
#include <QtWidgets>
#include <QtDebug>
#include <fstream>
#include <QMessageBox>

MyOffFile::MyOffFile()
{
    number_of_vertices = 0;
    number_of_faces = 0;
}

void MyOffFile::readOffFile(string filename)
{
    string line;
    ifstream objFile(filename);
    for (int i =0; i < number_of_vertices ; i++){
        delete[] Vertices_Buffer[i];
        }
    for (int i =0; i < number_of_faces ; i++){
            delete[] Faces_Buffer[i];
        }
        getline (objFile,line);
        if (line.find("OFF") == string::npos){
            QMessageBox::critical(0,"Error","This is not an OFF file as it does not contain OFF in the first line.");
        }
        else{
            getline (objFile,line);
            sscanf(line.c_str(),"%d %d %d",&number_of_vertices,&number_of_faces,&number_of_edges);
            if ((number_of_vertices == 0)||(number_of_faces == 0)){
                QMessageBox::critical(0,"Error","Cannot read the number of vertices and number of faces.");
            }
            else{
                Vertices_Buffer = new float*[number_of_vertices];
                for(int i=0;i<number_of_vertices;i++){
                    Vertices_Buffer[i] = new float[3];
                }
                Faces_Buffer = new int*[number_of_faces];
                for(int i=0;i<number_of_faces;i++){
                    Faces_Buffer[i] = new int[3];
                }
                for(int i=0;i<number_of_vertices;i++){
                    getline (objFile,line);
                    if(line.empty())
                        i--;
                    else
                        sscanf(line.c_str(),"%f %f %f",&Vertices_Buffer[i][0],&Vertices_Buffer[i][1],&Vertices_Buffer[i][2]);
                }
                for(int i=0;i<number_of_faces;i++){
                    getline (objFile,line);
                    if(line.empty())
                        i--;
                    else{
                        sscanf(line.c_str(),"%d %d %d %d",&POINTS_PER_VERTEX,&Faces_Buffer[i][0],&Faces_Buffer[i][1],&Faces_Buffer[i][2]);
                        if(POINTS_PER_VERTEX != 3){
                           QMessageBox::critical(0,"Error","The mesh contains more than 3 points per face.");
                           for (int i =0; i < number_of_vertices ; i++){
                               delete[] Vertices_Buffer[i];
                               }
                           for (int i =0; i < number_of_faces ; i++){
                                   delete[] Faces_Buffer[i];
                               }
                           number_of_vertices = 0;
                           number_of_faces = 0;
                           number_of_edges = 0;
                           break;
                        }
                    }
                }
            }
        }
}

int MyOffFile::get_number_of_vertices()
{
    return number_of_vertices;
}

int MyOffFile::get_number_of_faces()
{
    return number_of_faces;
}

float **MyOffFile::get_Vertices_Buffer()
{
    return Vertices_Buffer;
}

int **MyOffFile::get_Faces_Buffer()
{
    return Faces_Buffer;
}

MyOffFile::~MyOffFile()
{
//    for (int i =0; i < number_of_vertices ; i++)
//    {
//        delete[] Vertices_Buffer[i];
//    }
//    for (int i =0; i < number_of_faces ; i++)
//    {
//        delete[] Faces_Buffer[i];
//    }
}
