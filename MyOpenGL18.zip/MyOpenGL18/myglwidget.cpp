// myglwidget.cpp

#include "myglwidget.h"
#include "window.h"
#include "ui_window.h"

extern Ui::Window * ui_new;
MyGLWidget::MyGLWidget(QWidget *parent)
    : QGLWidget(QGLFormat(QGL::SampleBuffers), parent)
{
    xRot = 0;
    yRot = 0;
    zRot = 0;
    xPos = 0.0;
    yPos = 0.0;

    zoomValue = 1.0;
    RObjColor = 1;
    GObjColor = 0;
    BObjColor = 0;

    RBackColor = 0;
    GBackColor = 0;
    BBackColor = 0;

    RPointColor = 0;
    GPointColor = 0;
    BPointColor = 1;

    RRingColor = 0;
    GRingColor = 1;
    BRingColor = 1;
    PointSize = 10.0;


    read_number_of_faces = 0;
    read_number_of_vertices = 0;
    size_result = 0;
    size_result_n =0;

    harris_parameter = 0.04;
    fraction  = 0.01;
    radius_param = 2;
    selection_type= "fraction";
    size_result_n =0;

    xVerMin = 0;
    xVerMax = 0;
    yVerMin = 0;
    yVerMax = 0;
    zVerMin = 0;
    zVerMax = 0;

    globalVerMinNorm = 0;
    globalVerMaxNorm = 0;

    MeshLines_checked = 0;
}

MyGLWidget::~MyGLWidget()
{
}

//minimumSizeHint and sizeHint functions are needed when resizing the window
QSize MyGLWidget::minimumSizeHint() const
{
    return QSize(50, 50);
}

QSize MyGLWidget::sizeHint() const
{
    return QSize(400, 400);
}

// from the source code available at https://www.bogotobogo.com/
// the angle is increase or decreased every 16 pixels move, to allow for more convenient rotation
// this is why we see this hard-coded 16 value here and there
// a trackball approach using quaternion would be more elegant...

static void qNormalizeAngle(int &angle)
{
    // urgl, it kind of hurts, but it works ;)
    while (angle < 0)
        angle += 360 * 16;
    while (angle > 360)
        angle -= 360 * 16;
}

//implementation of the 3 slots to catch rotation values from sliders and update the openglwidget
void MyGLWidget::setXRotation(int angle)
{
    //we assert the rotation value makes sense
    qNormalizeAngle(angle);

    if (angle != xRot) {//if rotation has changed
        xRot = angle; // update value
        emit xRotationChanged(angle); // emit a signal that carries the angular value
        updateGL(); // draw the scene
    }
}

// same goes for the Y and Z axis
void MyGLWidget::setYRotation(int angle)
{
    qNormalizeAngle(angle);
    if (angle != yRot) {
        yRot = angle;
        emit yRotationChanged(angle);
        updateGL();
    }
}

void MyGLWidget::setZRotation(int angle)
{
    qNormalizeAngle(angle);
    if (angle != zRot) {
        zRot = angle;
        emit zRotationChanged(angle);
        updateGL();
    }
}

void MyGLWidget::loadOFFFile()
{
    filename = QFileDialog::getOpenFileName(this, tr("Open File"),"C://", "All files (*.*);;Text File (*.off)");
    QFile file(filename);
    if(!file.open(QFile::ReadOnly|QFile::Text)){
        if(!filename.isEmpty())
            QMessageBox::critical(0,"Error","Cannot open the file.");
    }
    else{
        MyOffFile off_file;
        off_file.readOffFile(filename.toUtf8().constData());

        //Delete the Harris point matrices
        for (int i = 0; i < size_result; i++){
            delete[] result[i];
            delete[] result_norm[i];
        }
        size_result = 0;

        //Delete the Rings matrices
        for (int i = 0; i < size_result_n; i++)
            delete[] result_n[i];
        size_result_n =0;
        //To reset tranlation loacation
        xPos = 0;
        yPos = 0;
        glTranslatef(xPos, yPos, -10.0);

        //To reset zoom loacation
        zoomValue = 1.0;
        glScalef(zoomValue, zoomValue, zoomValue);

        //To reset rotation loacation
        glLoadIdentity();

        xRot = 0;
        yRot = 0;
        zRot = 0;

        emit xRotationChanged(0);
        emit yRotationChanged(0);
        emit zRotationChanged(0);
        glRotatef(xRot / 16.0, 1.0, 0.0, 0.0);
        glRotatef(yRot / 16.0, 0.0, 1.0, 0.0);
        glRotatef(zRot / 16.0, 0.0, 0.0, 1.0);

        read_Faces_Buffer = off_file.get_Faces_Buffer();
        read_Vertices_Buffer = off_file.get_Vertices_Buffer();
        read_number_of_faces = off_file.get_number_of_faces();
        read_number_of_vertices = off_file.get_number_of_vertices();

        if (read_number_of_vertices !=0){
            xVerMin = read_Vertices_Buffer[0][0];
            xVerMax = read_Vertices_Buffer[0][0];
            yVerMin = read_Vertices_Buffer[0][1];
            yVerMax = read_Vertices_Buffer[0][1];
            zVerMin = read_Vertices_Buffer[0][2];
            zVerMax = read_Vertices_Buffer[0][2];
            for(int i = 1;i<read_number_of_vertices;i++){
                if(read_Vertices_Buffer[i][0]>xVerMax)
                    xVerMax = read_Vertices_Buffer[i][0];
                if(read_Vertices_Buffer[i][0]<xVerMin)
                    xVerMin = read_Vertices_Buffer[i][0];
                if(read_Vertices_Buffer[i][1]>yVerMax)
                    yVerMax = read_Vertices_Buffer[i][1];
                if(read_Vertices_Buffer[i][1]<yVerMin)
                    yVerMin = read_Vertices_Buffer[i][1];
                if(read_Vertices_Buffer[i][2]>zVerMax)
                    zVerMax = read_Vertices_Buffer[i][2];
                if(read_Vertices_Buffer[i][2]<zVerMin)
                    zVerMin = read_Vertices_Buffer[i][2];
            }


        globalVerMax = xVerMax;
        globalVerMin = xVerMin;

        if(yVerMax>globalVerMax)
            globalVerMax = yVerMax;
        if(zVerMax>globalVerMax)
            globalVerMax = zVerMax;

        if(yVerMin<globalVerMin)
            globalVerMin = yVerMin;
        if(zVerMin<globalVerMin)
            globalVerMin = zVerMin;

        for(int i = 0;i<read_number_of_vertices;i++){
            read_Vertices_Buffer[i][0] = read_Vertices_Buffer[i][0]/(globalVerMax-globalVerMin);
            read_Vertices_Buffer[i][1] = read_Vertices_Buffer[i][1]/(globalVerMax-globalVerMin);
            read_Vertices_Buffer[i][2] = read_Vertices_Buffer[i][2]/(globalVerMax-globalVerMin);
        }

        globalVerMinNorm = globalVerMin/(globalVerMax-globalVerMin);
        globalVerMaxNorm = globalVerMax/(globalVerMax-globalVerMin);
        resizeGL(ui_new->myGLWidget->width(),ui_new->myGLWidget->height());

        }
        ui_new->HarrisVerticeslistWidget->clear();
        updateGL();
    }

}

void MyGLWidget::calculateHarrisPoints()
{
    QString parameters;
    parameters = QString("Neighborhood type: %1\n"
                         "Diagonal fraction: %2\n"
                         "Rings number: %3\n"
                         "Harris parameter: %4\n"
                         ).arg(QString::fromStdString(selection_type)).arg(fraction).arg(radius_param).arg(harris_parameter);
    QMessageBox::information(this,"Detection parameters",parameters);
    for (int i = 0; i < size_result; i++){
        delete[] result[i];
        delete[] result_norm[i];
    }

    //Clear rings
    for (int i = 0; i < size_result_n; i++){
        delete[] result_n[i];
    }
    size_result_n = 0;

    ret = cal_interest_points(result, size_result, filename.toUtf8().constData(),harris_parameter,fraction,radius_param,selection_type);
    ui_new->HarrisVerticeslistWidget->clear();
    QString list_item_str;
    for (int i = 0; i < size_result; i++)
    {
        list_item_str = QString("%1: %2, %3, %4").arg(i).arg(result[i][0]).arg(result[i][1]).arg(result[i][2]);
        ui_new->HarrisVerticeslistWidget->addItem(list_item_str);
    }
    list_item_str = QString("Clear all rings");

    ui_new->HarrisVerticeslistWidget->addItem(list_item_str);

    result_norm = new double*[size_result];
    for(int i=0;i<size_result;i++){
        result_norm[i] = new double[3];
    }
    for (int i = 0; i < size_result; i++)
    {
        result_norm[i][0] = result[i][0]/(globalVerMax-globalVerMin);
        result_norm[i][1] = result[i][1]/(globalVerMax-globalVerMin);
        result_norm[i][2] = result[i][2]/(globalVerMax-globalVerMin);
    }
    updateGL();

}

void MyGLWidget::changeObjRColor(int R_obj)
{

    if ((R_obj/100.0) != RObjColor) {
        RObjColor = R_obj/100.0;
        updateGL();
    }
}

void MyGLWidget::changeObjGColor(int G_obj)
{
    if ((G_obj/100.0) != GObjColor) {
        GObjColor = G_obj/100.0;
        updateGL();
    }
}

void MyGLWidget::changeObjBColor(int B_obj)
{
    if ((B_obj/100.0) != BObjColor) {
        BObjColor = B_obj/100.0;
        updateGL();
    }

}

void MyGLWidget::changePointRColor(int R_point)
{
    if ((R_point/100.0) != RPointColor) {
        RPointColor = R_point/100.0;
        updateGL();
    }

}

void MyGLWidget::changePointGColor(int G_point)
{
    if ((G_point/100.0) != GPointColor) {
        GPointColor = G_point/100.0;
        updateGL();
    }
}

void MyGLWidget::changePointBColor(int B_point)
{
    if ((B_point/100.0) != BPointColor) {
        BPointColor = B_point/100.0;
        updateGL();
    }
}

void MyGLWidget::changePointSize(int S_point)
{
    if ((S_point/5.0) != PointSize) {
        PointSize = S_point/5.0;
        updateGL();
    }
}

void MyGLWidget::changeBackRColor(int R_back)
{
    if ((R_back/100.0) != RBackColor) {
        RBackColor = R_back/100.0;
        updateGL();
    }

}

void MyGLWidget::changeBackGColor(int G_back)
{
    if ((G_back/100.0) != GBackColor) {
        GBackColor = G_back/100.0;
        updateGL();
    }
}

void MyGLWidget::changeBackBColor(int B_back)
{
    if ((B_back/100.0) != BBackColor) {
        BBackColor = B_back/100.0;
        updateGL();
    }

}

void MyGLWidget::changeRingRColor(int R_ring)
{
    if ((R_ring/100.0) != RRingColor) {
        RRingColor = R_ring/100.0;
        updateGL();
    }
}

void MyGLWidget::changeRingGColor(int G_ring)
{
    if ((G_ring/100.0) != GRingColor) {
        GRingColor = G_ring/100.0;
        updateGL();
    }
}

void MyGLWidget::changeRingBColor(int B_ring)
{
    if ((B_ring/100.0) != BRingColor) {
        BRingColor = B_ring/100.0;
        updateGL();
    }
}

void MyGLWidget::getDFlineEditValue(QString DF_val)
{
    fraction  = DF_val.toDouble();
}

void MyGLWidget::getRNlineEditValue(QString RN_val)
{
    radius_param = RN_val.toInt();
}

void MyGLWidget::getHPlineEditValue(QString HP_val)
{
    harris_parameter = HP_val.toDouble();
}

void MyGLWidget::getIPScomboBoxValue(int IPS_val)
{
    if(IPS_val == 0)
        selection_type= "fraction";
    else if(IPS_val == 1)
        selection_type= "clustering";
}

void MyGLWidget::getHVlistWidgetValue(QModelIndex HV_Val)
{
    for (int i =0; i < size_result_n ; i++)
    {
        delete[] result_n[i];
    }
    delete [] result_n;
    delete[] face;
    if(HV_Val.row()==(size_result))
        size_result_n =0;
    else
        int ret2 = get_faces(result_n,face, size_result_n, filename.toUtf8().constData(),radius_param, result[HV_Val.row()][0], result[HV_Val.row()][1] , result[HV_Val.row()][2]);
        qDebug() << "Faces Number: " << size_result_n << endl;
    updateGL();

}

//If mesh line checkbox checked or not
void MyGLWidget::MLchecked(bool ML_chk)
{
    MeshLines_checked = ML_chk;
    updateGL();

}

void MyGLWidget::initializeGL()
{
        //init background color
        glClearColor(RBackColor,GBackColor,BBackColor, 1.0f);

        //enable depth test
        glEnable(GL_DEPTH_TEST);

        //enable face culling, see https://learnopengl.com/Advanced-OpenGL/Face-culling
        glEnable(GL_CULL_FACE);

        //enable smooth (linear color interpolation)
        glShadeModel(GL_SMOOTH);

        glLightModeli(GL_LIGHT_MODEL_LOCAL_VIEWER,GL_TRUE);

        //we now set the light position
        GLfloat light_ambient[] = {0.2, 0.2, 0.2, 1.0};
        GLfloat light_diffuse[] = {0.8, 0.8, 0.8, 1.0};
        GLfloat light_specular[] = {1.0, 1.0, 1.0, 1.0};
        glLightfv(GL_LIGHT0, GL_AMBIENT, light_ambient);
        glLightfv(GL_LIGHT0, GL_DIFFUSE, light_diffuse);
        glLightfv(GL_LIGHT0, GL_SPECULAR, light_specular);
        static GLfloat lightPosition[4] = { 0, 0, 2, 1.0 };
        glLightfv(GL_LIGHT0, GL_POSITION, lightPosition);
        //we need at least 1 light to see something
        glEnable(GL_LIGHTING);
        //light0 is the default one
        glEnable(GL_LIGHT0);

        GLfloat qaBlack[] = {0.0, 0.0, 0.0, 1.0};
        GLfloat qaGreen[] = {0.0, 1.0, 0.0, 1.0};
        GLfloat qaWhite[] = {1.0, 1.0, 1.0, 1.0};
        GLfloat low_sh[] = {60.0};
        glMaterialfv(GL_FRONT, GL_AMBIENT, qaBlack);
        glMaterialfv(GL_FRONT, GL_DIFFUSE, qaBlack);
        glMaterialfv(GL_FRONT, GL_SPECULAR, qaWhite);
        glMaterialfv(GL_FRONT, GL_SHININESS, low_sh);
        glEnable(GL_COLOR_MATERIAL);

        glEnable(GL_NORMALIZE);
}

//paintGL is called whenever the GLwidget needs to be drawn.
//it first inits the transforms then calls the draw() member function
void MyGLWidget::paintGL()
{

    glClearColor(RBackColor,GBackColor,BBackColor, 1.0f);
    glEnable(GL_DEPTH_TEST);

    //glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH);
    //first, clear everything
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    //reset any transform
    glLoadIdentity();

    //translate to see the object. Comment that ligne to see the changes
    glTranslatef(xPos, yPos, -10.0);

    glScalef(zoomValue, zoomValue, zoomValue);

    //apply rotations along x, y, then z axis


    glRotatef(xRot / 16.0, 1.0, 0.0, 0.0);
    glRotatef(yRot / 16.0, 0.0, 1.0, 0.0);
    glRotatef(zRot / 16.0, 0.0, 0.0, 1.0);
    draw();
}

//resizeGL is used when the GLwidget is resized
void MyGLWidget::resizeGL(int width, int height)
{

    //first, we need to adjust the viewport,
    //see https://www.khronos.org/registry/OpenGL-Refpages/es2.0/xhtml/glViewport.xml

    int side = qMin(width, height);
    glViewport((width - side) / 2, (height - side) / 2, side, side);

    //glMatrixMode is used to activate the world in which some transforms will be applied
    //https://www.khronos.org/registry/OpenGL-Refpages/gl2.1/xhtml/glMatrixMode.xml

    glMatrixMode(GL_PROJECTION); //basically, we are working in the rendered image, in pixels
    glLoadIdentity();

    //Hmmm, QT might use various opengl emulators, so glOrtho might be replaced by glOrthof
//    GLfloat glorthomin_val = xVerMin/(globalVerMax-globalVerMin);
//    GLfloat glorthomax_val = xVerMax/(globalVerMax-globalVerMin);
//    if((yVerMin/(globalVerMax-globalVerMin))<glorthomin_val)
//        glorthomin_val = yVerMin/(globalVerMax-globalVerMin);
//    if((yVerMax/(globalVerMax-globalVerMin))>glorthomax_val)
//        glorthomax_val = yVerMax/(globalVerMax-globalVerMin);
    #ifdef QT_OPENGL_ES_1
        glOrthof(globalVerMinNorm, globalVerMaxNorm, globalVerMinNorm, globalVerMaxNorm, 1.0, 15.0);
    #else
        glOrtho(globalVerMinNorm, globalVerMaxNorm, globalVerMinNorm, globalVerMaxNorm, 1.0, 15.0);
    #endif

    glMatrixMode(GL_MODELVIEW);
}

void MyGLWidget::mousePressEvent(QMouseEvent *event)
{
    switch( event->buttons() ) {
    case Qt::LeftButton:
        lastPos = event->pos();
        break;
    }
}

void MyGLWidget::mouseMoveEvent(QMouseEvent *event)
{
    int dx = event->x() - lastPos.x();
    int dy = event->y() - lastPos.y();
    if (event->buttons() & Qt::LeftButton) {
        xPos = xPos + double(dx)/150;
        yPos = yPos - double(dy)/150;
        updateGL();

    } else if (event->buttons() & Qt::RightButton) {
        setXRotation(xRot + 8 * dy);
        setYRotation(yRot + 8 * dx);
    }
    lastPos = event->pos();

}

void MyGLWidget::wheelEvent(QWheelEvent *event)
{

    QPoint numDegrees = event->angleDelta() / 8;
    if (!numDegrees.isNull()) {
        if(numDegrees.y()>0)
            zoomValue = zoomValue + 0.05;
        else
            zoomValue = zoomValue - 0.05;
        updateGL();
    }
}

void MyGLWidget::draw()
{
    glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);

    for(int i=0;i<size_result_n;i++){
        vect1[0] = read_Vertices_Buffer[result_n[i][1]][0] - read_Vertices_Buffer[result_n[i][0]][0];
        vect1[1] = read_Vertices_Buffer[result_n[i][1]][1] - read_Vertices_Buffer[result_n[i][0]][1];
        vect1[2] = read_Vertices_Buffer[result_n[i][1]][2] - read_Vertices_Buffer[result_n[i][0]][2];

        vect2[0] = read_Vertices_Buffer[result_n[i][2]][0] - read_Vertices_Buffer[result_n[i][0]][0];
        vect2[1] = read_Vertices_Buffer[result_n[i][2]][1] - read_Vertices_Buffer[result_n[i][0]][1];
        vect2[2] = read_Vertices_Buffer[result_n[i][2]][2] - read_Vertices_Buffer[result_n[i][0]][2];

        norm_vect[0] = vect1[1]*vect2[2] - vect1[2]*vect2[1];
        norm_vect[1] = vect1[2]*vect2[0] - vect1[0]*vect2[2];
        norm_vect[2] = vect1[0]*vect2[1] - vect1[1]*vect2[0];

       glNormal3f(norm_vect[0],norm_vect[1],norm_vect[2]);
       glColor3f(RRingColor,GRingColor,BRingColor);
        glBegin(GL_TRIANGLES);
            glVertex3f(read_Vertices_Buffer[result_n[i][0]][0],read_Vertices_Buffer[result_n[i][0]][1],read_Vertices_Buffer[result_n[i][0]][2]);
            glVertex3f(read_Vertices_Buffer[result_n[i][1]][0],read_Vertices_Buffer[result_n[i][1]][1],read_Vertices_Buffer[result_n[i][1]][2]);
            glVertex3f(read_Vertices_Buffer[result_n[i][2]][0],read_Vertices_Buffer[result_n[i][2]][1],read_Vertices_Buffer[result_n[i][2]][2]);
        glEnd();
    }

    for(int i=0;i<read_number_of_faces;i++){
        vect1[0] = read_Vertices_Buffer[read_Faces_Buffer[i][1]][0] - read_Vertices_Buffer[read_Faces_Buffer[i][0]][0];
        vect1[1] = read_Vertices_Buffer[read_Faces_Buffer[i][1]][1] - read_Vertices_Buffer[read_Faces_Buffer[i][0]][1];
        vect1[2] = read_Vertices_Buffer[read_Faces_Buffer[i][1]][2] - read_Vertices_Buffer[read_Faces_Buffer[i][0]][2];

        vect2[0] = read_Vertices_Buffer[read_Faces_Buffer[i][2]][0] - read_Vertices_Buffer[read_Faces_Buffer[i][0]][0];
        vect2[1] = read_Vertices_Buffer[read_Faces_Buffer[i][2]][1] - read_Vertices_Buffer[read_Faces_Buffer[i][0]][1];
        vect2[2] = read_Vertices_Buffer[read_Faces_Buffer[i][2]][2] - read_Vertices_Buffer[read_Faces_Buffer[i][0]][2];

        norm_vect[0] = vect1[1]*vect2[2] - vect1[2]*vect2[1];
        norm_vect[1] = vect1[2]*vect2[0] - vect1[0]*vect2[2];
        norm_vect[2] = vect1[0]*vect2[1] - vect1[1]*vect2[0];

        glNormal3f(norm_vect[0],norm_vect[1],norm_vect[2]);
        glColor3f(RObjColor,GObjColor,BObjColor);
        glBegin(GL_TRIANGLES);
            glVertex3f(read_Vertices_Buffer[read_Faces_Buffer[i][0]][0],read_Vertices_Buffer[read_Faces_Buffer[i][0]][1],read_Vertices_Buffer[read_Faces_Buffer[i][0]][2]);
            glVertex3f(read_Vertices_Buffer[read_Faces_Buffer[i][1]][0],read_Vertices_Buffer[read_Faces_Buffer[i][1]][1],read_Vertices_Buffer[read_Faces_Buffer[i][1]][2]);
            glVertex3f(read_Vertices_Buffer[read_Faces_Buffer[i][2]][0],read_Vertices_Buffer[read_Faces_Buffer[i][2]][1],read_Vertices_Buffer[read_Faces_Buffer[i][2]][2]);
        glEnd();
    }


    if(MeshLines_checked){
        glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
        for(int i=0;i<read_number_of_faces;i++){
            glColor3f(0.0f, 0.0f, 0.0f);
            glBegin(GL_TRIANGLES);
                glVertex3f(read_Vertices_Buffer[read_Faces_Buffer[i][0]][0],read_Vertices_Buffer[read_Faces_Buffer[i][0]][1],read_Vertices_Buffer[read_Faces_Buffer[i][0]][2]);
                glVertex3f(read_Vertices_Buffer[read_Faces_Buffer[i][1]][0],read_Vertices_Buffer[read_Faces_Buffer[i][1]][1],read_Vertices_Buffer[read_Faces_Buffer[i][1]][2]);
                glVertex3f(read_Vertices_Buffer[read_Faces_Buffer[i][2]][0],read_Vertices_Buffer[read_Faces_Buffer[i][2]][1],read_Vertices_Buffer[read_Faces_Buffer[i][2]][2]);
            glEnd();
        }
    }

    glPointSize(PointSize); //Set the Point size
    glColor3f(RPointColor, GPointColor, BPointColor); //Set the Point color
    for (int i = 0; i < size_result; i++)
    {
        glBegin (GL_POINTS);
            glVertex3f (result_norm[i][0], result_norm[i][1], result_norm[i][2]);
        glEnd ();
    }
}
